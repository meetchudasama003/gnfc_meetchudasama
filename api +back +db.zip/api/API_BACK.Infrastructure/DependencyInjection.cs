using API_BACK.Application.Interfaces.Files;
using API_BACK.Application.Interfaces.Persistence;
using API_BACK.Application.Interfaces.Security;
using API_BACK.Infrastructure.Files;
using API_BACK.Infrastructure.Persistence;
using API_BACK.Infrastructure.Security;
using API_BACK.Infrastructure.Settings;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace API_BACK.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JwtSettings>(configuration.GetSection(JwtSettings.SectionName));

        // Persistence (Dapper + SQL Server)
        services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IProductRepository, ProductRepository>();

        // Security
        services.AddSingleton<IPasswordHasher, IdentityPasswordHasher>();
        services.AddSingleton<ITokenService, JwtTokenService>();

        // Files (ClosedXML)
        services.AddSingleton<ISpreadsheetReader, ClosedXmlSpreadsheetReader>();

        return services;
    }
}
