using System.Globalization;
using API_BACK.Application.Exceptions;
using API_BACK.Application.Interfaces.Files;
using API_BACK.Application.Models;
using ClosedXML.Excel;
using Microsoft.Extensions.Logging;

namespace API_BACK.Infrastructure.Files;

internal sealed class ClosedXmlSpreadsheetReader : ISpreadsheetReader
{
    private readonly ILogger<ClosedXmlSpreadsheetReader> _logger;

    public ClosedXmlSpreadsheetReader(ILogger<ClosedXmlSpreadsheetReader> logger)
    {
        _logger = logger;
    }

    public SpreadsheetData Read(Stream content, int maxDataRows)
    {
        XLWorkbook workbook;
        try
        {
            workbook = new XLWorkbook(content);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Uploaded file could not be opened as a workbook.");
            throw new ValidationException("File is not a valid Excel workbook.");
        }

        using (workbook)
        {
            var sheet = workbook.Worksheets.FirstOrDefault()
                ?? throw new ValidationException("The workbook contains no worksheets.");

            // The header is always row 1; an empty row 1 yields no headers.
            var headerRow = sheet.Row(1);
            var lastColumn = headerRow.LastCellUsed()?.Address.ColumnNumber ?? 0;
            var headers = ReadCells(headerRow, lastColumn);

            var rows = sheet.RowsUsed()
                .Where(r => r.RowNumber() > 1)
                .Take(maxDataRows + 1)
                .Select(r => new SpreadsheetRow(r.RowNumber(), ReadCells(r, lastColumn)))
                .ToList();

            return new SpreadsheetData(headers, rows);
        }
    }

    private static List<string> ReadCells(IXLRow row, int lastColumn)
        => Enumerable.Range(1, lastColumn).Select(c => ReadCell(row.Cell(c))).ToList();

    // Reads a cell as an invariant-culture string so numeric cells parse consistently
    // regardless of the cell's display format.
    private static string ReadCell(IXLCell cell)
    {
        var value = cell.Value;
        if (value.IsBlank) return string.Empty;
        if (value.IsNumber) return value.GetNumber().ToString("0.############", CultureInfo.InvariantCulture);
        return value.ToString(CultureInfo.InvariantCulture).Trim();
    }
}
