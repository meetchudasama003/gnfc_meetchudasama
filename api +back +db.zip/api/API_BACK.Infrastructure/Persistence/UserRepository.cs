using API_BACK.Application.Exceptions;
using API_BACK.Application.Interfaces.Persistence;
using API_BACK.Domain.Entities;
using Dapper;
using Microsoft.Data.SqlClient;

namespace API_BACK.Infrastructure.Persistence;

internal sealed class UserRepository : IUserRepository
{
    private readonly IDbConnectionFactory _connectionFactory;

    public UserRepository(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<UserEntity?> GetByEmailAsync(string email)
    {
        const string sql = """
            SELECT UserId, FullName, Email, MobileNumber, PasswordHash, CreatedAt
            FROM   dbo.Users
            WHERE  Email = @Email;
            """;
        using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        return await conn.QuerySingleOrDefaultAsync<UserEntity>(sql, new { Email = email });
    }

    public async Task<bool> EmailExistsAsync(string email)
    {
        const string sql = """
            SELECT CASE WHEN EXISTS (SELECT 1 FROM dbo.Users WHERE Email = @Email)
                        THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END;
            """;
        using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        return await conn.ExecuteScalarAsync<bool>(sql, new { Email = email });
    }

    public async Task<int> CreateAsync(UserEntity user)
    {
        const string sql = """
            INSERT INTO dbo.Users (FullName, Email, MobileNumber, PasswordHash, CreatedAt)
            OUTPUT INSERTED.UserId
            VALUES (@FullName, @Email, @MobileNumber, @PasswordHash, SYSUTCDATETIME());
            """;
        using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        try
        {
            return await conn.ExecuteScalarAsync<int>(sql, new
            {
                user.FullName,
                user.Email,
                user.MobileNumber,
                user.PasswordHash
            });
        }
        catch (SqlException ex) when (SqlErrors.IsUniqueViolation(ex))
        {
            throw new DuplicateKeyException("A user with this email already exists.", ex);
        }
    }

    public async Task<IEnumerable<UserEntity>> GetAllAsync()
    {
        const string sql = """
            SELECT UserId, FullName, Email, MobileNumber, PasswordHash, CreatedAt
            FROM   dbo.Users
            ORDER BY CreatedAt DESC;
            """;
        using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        return await conn.QueryAsync<UserEntity>(sql);
    }
}
