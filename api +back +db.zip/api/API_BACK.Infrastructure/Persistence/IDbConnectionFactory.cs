using System.Data;

namespace API_BACK.Infrastructure.Persistence;

internal interface IDbConnectionFactory
{
    Task<IDbConnection> CreateOpenConnectionAsync(CancellationToken ct = default);
}
