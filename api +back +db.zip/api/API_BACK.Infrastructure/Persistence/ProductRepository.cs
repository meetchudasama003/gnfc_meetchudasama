using API_BACK.Application.Exceptions;
using API_BACK.Application.Interfaces.Persistence;
using API_BACK.Domain.Entities;
using Dapper;
using Microsoft.Data.SqlClient;

namespace API_BACK.Infrastructure.Persistence;

// All SQL is parameterized — no string concatenation.
internal sealed class ProductRepository : IProductRepository
{
    private readonly IDbConnectionFactory _connectionFactory;

    public ProductRepository(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<ProductEntity>> GetAllAsync()
    {
        const string sql = """
            SELECT ProductId, ProductCode, ProductName, Category, UnitPrice, Quantity, CreatedAt
            FROM   dbo.Products
            ORDER BY ProductId DESC;
            """;
        using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        return await conn.QueryAsync<ProductEntity>(sql);
    }

    public async Task<HashSet<string>> GetAllCodesAsync()
    {
        const string sql = "SELECT ProductCode FROM dbo.Products;";
        using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        var codes = await conn.QueryAsync<string>(sql);
        // SQL Server's default collation is case-insensitive, so compare the same way here.
        return new HashSet<string>(codes, StringComparer.OrdinalIgnoreCase);
    }

    public async Task<int> InsertManyAsync(IReadOnlyCollection<ProductEntity> products)
    {
        const string sql = """
            INSERT INTO dbo.Products (ProductCode, ProductName, Category, UnitPrice, Quantity, CreatedAt)
            VALUES (@ProductCode, @ProductName, @Category, @UnitPrice, @Quantity, SYSUTCDATETIME());
            """;

        using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        using var tx = conn.BeginTransaction();
        try
        {
            var inserted = await conn.ExecuteAsync(sql, products, tx);
            tx.Commit();
            return inserted;
        }
        catch (SqlException ex) when (SqlErrors.IsUniqueViolation(ex))
        {
            tx.Rollback();
            throw new DuplicateKeyException("One or more product codes already exist.", ex);
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }
}
