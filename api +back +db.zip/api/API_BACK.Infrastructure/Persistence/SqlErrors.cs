using Microsoft.Data.SqlClient;

namespace API_BACK.Infrastructure.Persistence;

internal static class SqlErrors
{
    // SQL Server error numbers for unique constraint / unique index violations.
    private const int UniqueConstraintViolation = 2627;
    private const int UniqueIndexViolation = 2601;

    public static bool IsUniqueViolation(SqlException ex)
        => ex.Number is UniqueConstraintViolation or UniqueIndexViolation;
}
