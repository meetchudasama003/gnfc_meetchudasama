using API_BACK.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using IPasswordHasher = API_BACK.Application.Interfaces.Security.IPasswordHasher;

namespace API_BACK.Infrastructure.Security;

// Adapter over ASP.NET Core Identity's PasswordHasher (PBKDF2 with a per-password salt).
internal sealed class IdentityPasswordHasher : IPasswordHasher
{
    private readonly PasswordHasher<UserEntity> _hasher = new();

    public string Hash(UserEntity user, string password) => _hasher.HashPassword(user, password);

    public bool Verify(UserEntity user, string password)
        => _hasher.VerifyHashedPassword(user, user.PasswordHash, password) != PasswordVerificationResult.Failed;
}
