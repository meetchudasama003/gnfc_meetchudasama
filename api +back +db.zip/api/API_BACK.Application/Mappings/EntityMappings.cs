using API_BACK.Application.DTOs.Responses;
using API_BACK.Domain.Entities;

namespace API_BACK.Application.Mappings;

// Entity → response DTO. Entities never leave the Application layer.
internal static class EntityMappings
{
    // PasswordHash is deliberately not mapped.
    public static UserResponse ToResponse(this UserEntity entity) => new()
    {
        UserId = entity.UserId,
        FullName = entity.FullName,
        Email = entity.Email,
        MobileNumber = entity.MobileNumber,
        CreatedAt = AsUtc(entity.CreatedAt)
    };

    public static ProductResponse ToResponse(this ProductEntity entity) => new()
    {
        ProductId = entity.ProductId,
        ProductCode = entity.ProductCode,
        ProductName = entity.ProductName,
        Category = entity.Category,
        UnitPrice = entity.UnitPrice,
        Quantity = entity.Quantity,
        CreatedAt = AsUtc(entity.CreatedAt)
    };

    // Stored via SYSUTCDATETIME(); mark as UTC so JSON carries the "Z" suffix.
    private static DateTime AsUtc(DateTime value) => DateTime.SpecifyKind(value, DateTimeKind.Utc);
}
