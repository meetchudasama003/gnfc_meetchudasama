using API_BACK.Domain.Entities;

namespace API_BACK.Application.Interfaces.Persistence;

public interface IProductRepository
{
    Task<IEnumerable<ProductEntity>> GetAllAsync();

    // Case-insensitive set of every existing ProductCode.
    Task<HashSet<string>> GetAllCodesAsync();

    // Inserts all products in a single transaction: either every row is saved or none is.
    // Throws DuplicateKeyException if a ProductCode already exists.
    Task<int> InsertManyAsync(IReadOnlyCollection<ProductEntity> products);
}
