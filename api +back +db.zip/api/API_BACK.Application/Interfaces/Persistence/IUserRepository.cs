using API_BACK.Domain.Entities;

namespace API_BACK.Application.Interfaces.Persistence;

public interface IUserRepository
{
    Task<UserEntity?> GetByEmailAsync(string email);
    Task<bool> EmailExistsAsync(string email);

    // Throws DuplicateKeyException if the email already exists.
    Task<int> CreateAsync(UserEntity user);

    Task<IEnumerable<UserEntity>> GetAllAsync();
}
