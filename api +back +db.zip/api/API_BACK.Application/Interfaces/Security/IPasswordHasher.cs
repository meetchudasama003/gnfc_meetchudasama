using API_BACK.Domain.Entities;

namespace API_BACK.Application.Interfaces.Security;

public interface IPasswordHasher
{
    string Hash(UserEntity user, string password);

    // Verifies the password against user.PasswordHash.
    bool Verify(UserEntity user, string password);
}
