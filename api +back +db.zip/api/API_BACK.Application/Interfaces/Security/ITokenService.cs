using API_BACK.Application.Models;
using API_BACK.Domain.Entities;

namespace API_BACK.Application.Interfaces.Security;

public interface ITokenService
{
    AccessToken CreateToken(UserEntity user);
}
