using API_BACK.Application.Models;

namespace API_BACK.Application.Interfaces.Files;

public interface ISpreadsheetReader
{
    // Reads the first worksheet: row 1 as headers, then every non-empty row below it.
    // Reads at most maxDataRows + 1 data rows so the caller can detect oversized sheets
    // without loading them fully. Throws ValidationException if the workbook cannot be read.
    SpreadsheetData Read(Stream content, int maxDataRows);
}
