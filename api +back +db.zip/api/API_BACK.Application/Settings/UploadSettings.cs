namespace API_BACK.Application.Settings;

public class UploadSettings
{
    public const string SectionName = "Upload";

    public long MaxFileSizeBytes { get; set; } = 5 * 1024 * 1024;
    public string AllowedExtension { get; set; } = ".xlsx";
}
