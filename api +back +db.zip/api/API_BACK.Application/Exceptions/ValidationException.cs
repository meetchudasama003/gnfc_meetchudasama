namespace API_BACK.Application.Exceptions;

// Input breaks a business rule (bad file, missing columns, ...).
public class ValidationException : AppException
{
    public ValidationException(string message) : base(message)
    {
    }
}
