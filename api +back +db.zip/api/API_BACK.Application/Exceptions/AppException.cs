namespace API_BACK.Application.Exceptions;

// Base for expected, client-facing failures. The message is always safe to return to the caller;
// the API layer decides which HTTP status each subtype maps to.
public abstract class AppException : Exception
{
    protected AppException(string message) : base(message)
    {
    }
}
