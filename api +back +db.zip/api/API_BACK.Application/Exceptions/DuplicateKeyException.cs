namespace API_BACK.Application.Exceptions;

// Thrown by persistence implementations when a unique constraint is violated,
// so the Application layer can react without knowing about the database engine.
public class DuplicateKeyException : Exception
{
    public DuplicateKeyException(string message, Exception? innerException = null)
        : base(message, innerException)
    {
    }
}
