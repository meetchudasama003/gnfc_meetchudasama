namespace API_BACK.Application.Exceptions;

// The request conflicts with existing data (duplicate email, concurrent duplicate product code, ...).
public class ConflictException : AppException
{
    public ConflictException(string message) : base(message)
    {
    }
}
