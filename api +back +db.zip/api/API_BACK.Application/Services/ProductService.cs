using System.Globalization;
using API_BACK.Application.DTOs.Responses;
using API_BACK.Application.DTOs.Results;
using API_BACK.Application.Exceptions;
using API_BACK.Application.Interfaces.Files;
using API_BACK.Application.Interfaces.Persistence;
using API_BACK.Application.Mappings;
using API_BACK.Application.Models;
using API_BACK.Application.Services.Interfaces;
using API_BACK.Application.Settings;
using API_BACK.Domain.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace API_BACK.Application.Services;

public class ProductService : IProductService
{
    private const int MaxDataRows = 10_000;

    // OOXML files are ZIP archives: "PK\x03\x04".
    private static readonly byte[] ZipMagicBytes = { 0x50, 0x4B, 0x03, 0x04 };

    // Exact header row (row 1), in this column order.
    private static readonly string[] RequiredColumns =
        { "ProductCode", "ProductName", "Category", "UnitPrice", "Quantity" };

    private const int CodeColumn = 0, NameColumn = 1, CategoryColumn = 2, PriceColumn = 3, QuantityColumn = 4;

    private readonly IProductRepository _productRepository;
    private readonly ISpreadsheetReader _spreadsheetReader;
    private readonly UploadSettings _uploadSettings;
    private readonly ILogger<ProductService> _logger;

    public ProductService(
        IProductRepository productRepository,
        ISpreadsheetReader spreadsheetReader,
        IOptions<UploadSettings> uploadSettings,
        ILogger<ProductService> logger)
    {
        _productRepository = productRepository;
        _spreadsheetReader = spreadsheetReader;
        _uploadSettings = uploadSettings.Value;
        _logger = logger;
    }

    public async Task<IEnumerable<ProductResponse>> GetAllAsync()
    {
        var products = await _productRepository.GetAllAsync();
        return products.Select(p => p.ToResponse());
    }

    public async Task<ProductImportResult> ImportAsync(FileUpload? file)
    {
        // 1-3. File-level checks: presence, size, extension, magic bytes.
        ValidateFile(file);

        await using var buffer = new MemoryStream();
        await file!.Content.CopyToAsync(buffer);
        buffer.Position = 0;

        if (!HasZipSignature(buffer))
            throw new ValidationException("File is not a valid Excel workbook.");
        buffer.Position = 0;

        // 4. Read the workbook (Infrastructure).
        var sheet = _spreadsheetReader.Read(buffer, MaxDataRows);

        // 5. Verify headers (row 1, columns 1-5, case-insensitive).
        ValidateHeaders(sheet.Headers);

        if (sheet.Rows.Count == 0)
            throw new ValidationException("The worksheet contains no data rows.");
        if (sheet.Rows.Count > MaxDataRows)
            throw new ValidationException($"The worksheet exceeds the maximum of {MaxDataRows} data rows.");

        // 6. One query for all existing codes.
        var dbCodes = await _productRepository.GetAllCodesAsync();

        // 7. Working sets.
        var validRows = new List<ProductEntity>();
        var rejectedRows = new List<RowValidationError>();
        var seenInFile = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // 8. Validate each row.
        foreach (var row in sheet.Rows)
        {
            var (entity, errors) = ValidateRow(row, seenInFile, dbCodes);

            if (errors.Count > 0)
            {
                rejectedRows.Add(new RowValidationError
                {
                    RowNumber = row.RowNumber,
                    ProductCode = row.Cells[CodeColumn],
                    Errors = errors
                });
            }
            else
            {
                validRows.Add(entity!);
                seenInFile.Add(entity!.ProductCode);
            }
        }

        // 9-11. Insert all valid rows atomically (no transaction when there is nothing to insert).
        var imported = validRows.Count > 0 ? await InsertAsync(validRows) : 0;

        // 12. Summary.
        return new ProductImportResult
        {
            TotalRecords = sheet.Rows.Count,
            ImportedRecords = imported,
            RejectedRecords = rejectedRows.Count,
            Errors = rejectedRows
        };
    }

    private void ValidateFile(FileUpload? file)
    {
        if (file is null || file.Length == 0)
            throw new ValidationException("No file uploaded.");

        if (file.Length > _uploadSettings.MaxFileSizeBytes)
            throw new ValidationException(FileTooLargeMessage(_uploadSettings));

        var extension = Path.GetExtension(file.FileName);
        if (!string.Equals(extension, _uploadSettings.AllowedExtension, StringComparison.OrdinalIgnoreCase))
            throw new ValidationException($"Only {_uploadSettings.AllowedExtension} files are accepted.");
    }

    public static string FileTooLargeMessage(UploadSettings settings)
        => $"File size must not exceed {settings.MaxFileSizeBytes / (1024 * 1024)} MB.";

    private static bool HasZipSignature(Stream stream)
    {
        Span<byte> header = stackalloc byte[4];
        return stream.Read(header) == 4 && header.SequenceEqual(ZipMagicBytes);
    }

    // Columns 1-5 of row 1 must match RequiredColumns exactly (case-insensitive); extra columns are ignored.
    private static void ValidateHeaders(IReadOnlyList<string> headers)
    {
        var valid = headers.Count >= RequiredColumns.Length
            && RequiredColumns.Select((expected, i) => string.Equals(headers[i].Trim(), expected, StringComparison.OrdinalIgnoreCase))
                              .All(match => match);

        if (!valid)
            throw new ValidationException($"Invalid column headers. Expected: {string.Join(", ", RequiredColumns)}");
    }

    // Collects every field error for the row, not just the first one.
    private static (ProductEntity? Entity, List<string> Errors) ValidateRow(
        SpreadsheetRow row,
        HashSet<string> seenInFile,
        HashSet<string> dbCodes)
    {
        var errors = new List<string>();

        var code = row.Cells[CodeColumn];
        var name = row.Cells[NameColumn];
        var category = row.Cells[CategoryColumn];
        var priceText = row.Cells[PriceColumn];
        var quantityText = row.Cells[QuantityColumn];

        // a-e. ProductCode
        if (code.Length == 0) errors.Add("ProductCode is required.");
        else if (code.Length > 50) errors.Add("ProductCode must not exceed 50 characters.");
        else
        {
            if (seenInFile.Contains(code)) errors.Add("Duplicate ProductCode in this file.");
            if (dbCodes.Contains(code)) errors.Add("ProductCode already exists in the database.");
        }

        // f-h. ProductName
        if (name.Length == 0) errors.Add("ProductName is required.");
        else if (name.Length > 200) errors.Add("ProductName must not exceed 200 characters.");

        // i-k. Category
        if (category.Length == 0) errors.Add("Category is required.");
        else if (category.Length > 100) errors.Add("Category must not exceed 100 characters.");

        // l-o. UnitPrice — DECIMAL(18,2), non-negative
        decimal price = 0;
        if (priceText.Length == 0)
            errors.Add("UnitPrice is required.");
        else if (!decimal.TryParse(priceText, NumberStyles.Number, CultureInfo.InvariantCulture, out price))
            errors.Add("UnitPrice must be a valid number.");
        else if (price < 0)
            errors.Add("UnitPrice must be zero or greater.");
        else if (price != Math.Round(price, 2))
            errors.Add("UnitPrice must have at most 2 decimal places.");
        else if (price > 9_999_999_999_999_999.99m)
            errors.Add("UnitPrice is too large.");

        // p-s. Quantity — whole number, non-negative
        int quantity = 0;
        if (quantityText.Length == 0)
            errors.Add("Quantity is required.");
        else if (!int.TryParse(quantityText, NumberStyles.Integer, CultureInfo.InvariantCulture, out quantity))
            errors.Add("Quantity must be a whole number.");
        else if (quantity < 0)
            errors.Add("Quantity must be zero or greater.");

        if (errors.Count > 0)
            return (null, errors);

        return (new ProductEntity
        {
            ProductCode = code,
            ProductName = name,
            Category = category,
            UnitPrice = price,
            Quantity = quantity
        }, errors);
    }

    private async Task<int> InsertAsync(List<ProductEntity> products)
    {
        try
        {
            return await _productRepository.InsertManyAsync(products);
        }
        catch (DuplicateKeyException ex)
        {
            // The repository has already rolled the transaction back.
            _logger.LogWarning(ex, "Product import rolled back due to a concurrent duplicate ProductCode.");
            throw new ConflictException(
                "Import aborted: one or more product codes were added by another user during the import. No records were saved; please retry.");
        }
    }
}
