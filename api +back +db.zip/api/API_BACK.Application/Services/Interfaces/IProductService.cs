using API_BACK.Application.DTOs.Responses;
using API_BACK.Application.DTOs.Results;
using API_BACK.Application.Models;

namespace API_BACK.Application.Services.Interfaces;

public interface IProductService
{
    Task<IEnumerable<ProductResponse>> GetAllAsync();

    // Throws ValidationException for file-level problems and ConflictException
    // if a concurrent import inserted one of the product codes.
    Task<ProductImportResult> ImportAsync(FileUpload? file);
}
