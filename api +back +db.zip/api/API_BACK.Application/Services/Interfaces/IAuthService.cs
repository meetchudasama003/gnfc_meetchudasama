using API_BACK.Application.DTOs.Requests;
using API_BACK.Application.DTOs.Responses;
using API_BACK.Application.DTOs.Results;

namespace API_BACK.Application.Services.Interfaces;

public interface IAuthService
{
    // Throws ConflictException if the email is already registered.
    Task<UserResponse> RegisterAsync(RegisterRequest request);

    // Returns null when the email/password combination is invalid.
    Task<AuthTokenResult?> LoginAsync(LoginRequest request);
}
