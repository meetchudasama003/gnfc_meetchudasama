using API_BACK.Application.DTOs.Responses;

namespace API_BACK.Application.Services.Interfaces;

public interface IUserService
{
    Task<IEnumerable<UserResponse>> GetAllAsync();
}
