using API_BACK.Application.DTOs.Responses;
using API_BACK.Application.Interfaces.Persistence;
using API_BACK.Application.Mappings;
using API_BACK.Application.Services.Interfaces;

namespace API_BACK.Application.Services;

public class UserService : IUserService
{
    private readonly IUserRepository _userRepository;

    public UserService(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public async Task<IEnumerable<UserResponse>> GetAllAsync()
    {
        var users = await _userRepository.GetAllAsync();
        return users.Select(u => u.ToResponse());
    }
}
