using API_BACK.Application.DTOs.Requests;
using API_BACK.Application.DTOs.Responses;
using API_BACK.Application.DTOs.Results;
using API_BACK.Application.Exceptions;
using API_BACK.Application.Interfaces.Persistence;
using API_BACK.Application.Interfaces.Security;
using API_BACK.Application.Mappings;
using API_BACK.Application.Services.Interfaces;
using API_BACK.Domain.Entities;

namespace API_BACK.Application.Services;

public class AuthService : IAuthService
{
    private const string EmailTakenMessage = "An account with this email already exists.";

    private readonly IUserRepository _userRepository;
    private readonly IPasswordHasher _passwordHasher;
    private readonly ITokenService _tokenService;

    public AuthService(IUserRepository userRepository, IPasswordHasher passwordHasher, ITokenService tokenService)
    {
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
        _tokenService = tokenService;
    }

    public async Task<UserResponse> RegisterAsync(RegisterRequest request)
    {
        var email = NormalizeEmail(request.Email);

        if (await _userRepository.EmailExistsAsync(email))
            throw new ConflictException(EmailTakenMessage);

        var entity = new UserEntity
        {
            FullName = request.FullName.Trim(),
            Email = email,
            MobileNumber = request.MobileNumber.Trim()
        };
        entity.PasswordHash = _passwordHasher.Hash(entity, request.Password);

        try
        {
            entity.UserId = await _userRepository.CreateAsync(entity);
        }
        catch (DuplicateKeyException)
        {
            // Lost a race with a concurrent registration — the DB constraint is the final guard.
            throw new ConflictException(EmailTakenMessage);
        }

        entity.CreatedAt = DateTime.UtcNow;
        return entity.ToResponse();
    }

    public async Task<AuthTokenResult?> LoginAsync(LoginRequest request)
    {
        var user = await _userRepository.GetByEmailAsync(NormalizeEmail(request.Email));
        if (user is null || !_passwordHasher.Verify(user, request.Password))
            return null;

        var token = _tokenService.CreateToken(user);

        return new AuthTokenResult(token.Token, new AuthResponse
        {
            FullName = user.FullName,
            Email = user.Email,
            ExpiresAt = token.ExpiresAt
        });
    }

    private static string NormalizeEmail(string email) => email.Trim().ToLowerInvariant();
}
