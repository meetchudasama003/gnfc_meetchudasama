namespace API_BACK.Application.DTOs.Responses;

// Safe user view — intentionally has no PasswordHash.
public class UserResponse
{
    public int UserId { get; init; }
    public string FullName { get; init; } = string.Empty;
    public string Email { get; init; } = string.Empty;
    public string MobileNumber { get; init; } = string.Empty;
    public DateTime CreatedAt { get; init; }
}
