namespace API_BACK.Application.DTOs.Responses;

// The raw JWT is delivered only as an HttpOnly cookie, never in a response body.
public class AuthResponse
{
    public string FullName { get; init; } = string.Empty;
    public string Email { get; init; } = string.Empty;
    public DateTime ExpiresAt { get; init; }
}
