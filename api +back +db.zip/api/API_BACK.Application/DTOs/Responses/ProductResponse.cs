namespace API_BACK.Application.DTOs.Responses;

public class ProductResponse
{
    public int ProductId { get; init; }
    public string ProductCode { get; init; } = string.Empty;
    public string ProductName { get; init; } = string.Empty;
    public string Category { get; init; } = string.Empty;
    public decimal UnitPrice { get; init; }
    public int Quantity { get; init; }
    public DateTime CreatedAt { get; init; }
}
