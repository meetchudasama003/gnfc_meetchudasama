using API_BACK.Application.DTOs.Responses;

namespace API_BACK.Application.DTOs.Results;

// Internal login result: the token goes into the HttpOnly cookie, only User goes in the response body.
public record AuthTokenResult(string Token, AuthResponse User);
