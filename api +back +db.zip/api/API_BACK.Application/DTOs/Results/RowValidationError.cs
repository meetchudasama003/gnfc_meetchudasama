namespace API_BACK.Application.DTOs.Results;

public class RowValidationError
{
    public int RowNumber { get; init; }
    public string ProductCode { get; init; } = string.Empty;
    public List<string> Errors { get; init; } = new();
}
