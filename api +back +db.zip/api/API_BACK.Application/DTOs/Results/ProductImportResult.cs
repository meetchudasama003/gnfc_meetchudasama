namespace API_BACK.Application.DTOs.Results;

public class ProductImportResult
{
    public int TotalRecords { get; init; }
    public int ImportedRecords { get; init; }
    public int RejectedRecords { get; init; }
    public List<RowValidationError> Errors { get; init; } = new();
}
