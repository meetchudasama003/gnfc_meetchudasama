namespace API_BACK.Application.Models;

// Raw contents of the first worksheet: the header row and every non-empty data row,
// with each cell read as an invariant-culture string. Interpreting the values is the
// Application layer's job; reading the file format is Infrastructure's.
public record SpreadsheetData(IReadOnlyList<string> Headers, IReadOnlyList<SpreadsheetRow> Rows);

// Cells has one entry per header column (same index as Headers).
public record SpreadsheetRow(int RowNumber, IReadOnlyList<string> Cells);
