namespace API_BACK.Application.Models;

public record AccessToken(string Token, DateTime ExpiresAt);
