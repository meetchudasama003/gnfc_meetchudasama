namespace API_BACK.Application.Models;

// Framework-neutral view of an uploaded file, so the Application layer does not depend on ASP.NET's IFormFile.
public record FileUpload(Stream Content, string FileName, long Length);
