using API_BACK.Contracts;
using API_BACK.Settings;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.Extensions.Options;

namespace API_BACK.Middleware;

// CSRF defence in depth for every state-changing request (POST/PUT/PATCH/DELETE):
//   1. Origin check — the Origin (or Referer) must be the SPA origin or the API itself.
//   2. Antiforgery token — the X-XSRF-TOKEN header must match the antiforgery cookie
//      (double-submit, validated by ASP.NET Core's IAntiforgery).
// Together with the SameSite=Strict auth cookie this gives three independent layers.
// Must run after UseCors (so 403s carry CORS headers) and UseAuthentication
// (tokens are bound to the signed-in user); it is placed after UseAuthorization
// so protected endpoints answer 401 to anonymous callers before the CSRF check.
public class CsrfProtectionMiddleware
{
    private static readonly HashSet<string> SafeMethods =
        new(StringComparer.OrdinalIgnoreCase) { "GET", "HEAD", "OPTIONS", "TRACE" };

    private readonly RequestDelegate _next;
    private readonly ILogger<CsrfProtectionMiddleware> _logger;
    private readonly string _allowedOrigin;

    public CsrfProtectionMiddleware(
        RequestDelegate next,
        ILogger<CsrfProtectionMiddleware> logger,
        IOptions<CorsSettings> corsSettings)
    {
        _next = next;
        _logger = logger;
        _allowedOrigin = corsSettings.Value.AllowedOrigin.TrimEnd('/');
    }

    public async Task InvokeAsync(HttpContext context, IAntiforgery antiforgery)
    {
        if (SafeMethods.Contains(context.Request.Method))
        {
            await _next(context);
            return;
        }

        if (!IsOriginAllowed(context.Request))
        {
            _logger.LogWarning("Blocked cross-site {Method} {Path} from origin {Origin}",
                context.Request.Method, context.Request.Path, GetRequestOrigin(context.Request));
            await RejectAsync(context, "Cross-site request blocked.");
            return;
        }

        if (!await antiforgery.IsRequestValidAsync(context))
        {
            _logger.LogWarning("Invalid or missing CSRF token for {Method} {Path}",
                context.Request.Method, context.Request.Path);
            await RejectAsync(context, "Invalid or missing CSRF token.");
            return;
        }

        await _next(context);
    }

    private bool IsOriginAllowed(HttpRequest request)
    {
        var origin = GetRequestOrigin(request);

        // Browsers always send Origin on cross-origin POSTs. A request with neither
        // Origin nor Referer comes from a non-browser client and still needs a valid token.
        if (origin is null)
            return true;

        var selfOrigin = $"{request.Scheme}://{request.Host}";
        return string.Equals(origin, _allowedOrigin, StringComparison.OrdinalIgnoreCase)
            || string.Equals(origin, selfOrigin, StringComparison.OrdinalIgnoreCase);
    }

    private static string? GetRequestOrigin(HttpRequest request)
    {
        var origin = request.Headers.Origin.ToString();
        if (!string.IsNullOrEmpty(origin))
            return origin.TrimEnd('/');

        var referer = request.Headers.Referer.ToString();
        if (Uri.TryCreate(referer, UriKind.Absolute, out var uri))
            return uri.GetLeftPart(UriPartial.Authority);

        return null;
    }

    private static async Task RejectAsync(HttpContext context, string message)
    {
        context.Response.StatusCode = StatusCodes.Status403Forbidden;
        await context.Response.WriteAsJsonAsync(ApiResponse<object>.Fail(message));
    }
}
