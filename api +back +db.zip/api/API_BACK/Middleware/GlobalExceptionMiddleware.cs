using API_BACK.Application.Exceptions;
using API_BACK.Application.Services;
using API_BACK.Application.Settings;
using API_BACK.Contracts;
using Microsoft.Extensions.Options;

namespace API_BACK.Middleware;

// Logs every unhandled exception in full, but only ever returns a sanitized message.
// Stack traces, exception types and inner messages never reach the client.
// Application exceptions carry safe messages and are mapped to HTTP status codes here,
// so the Application layer stays free of HTTP concerns.
public class GlobalExceptionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionMiddleware> _logger;

    public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (AppException ex)
        {
            await WriteAsync(context, MapStatusCode(ex), ex.Message);
        }
        catch (BadHttpRequestException ex) when (ex.StatusCode == StatusCodes.Status413PayloadTooLarge)
        {
            var uploadSettings = context.RequestServices.GetRequiredService<IOptions<UploadSettings>>().Value;
            await WriteAsync(context, StatusCodes.Status400BadRequest, ProductService.FileTooLargeMessage(uploadSettings));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception for {Method} {Path}", context.Request.Method, context.Request.Path);
            await WriteAsync(context, StatusCodes.Status500InternalServerError, "An unexpected error occurred.");
        }
    }

    private static int MapStatusCode(AppException ex) => ex switch
    {
        ValidationException => StatusCodes.Status400BadRequest,
        ConflictException => StatusCodes.Status409Conflict,
        _ => StatusCodes.Status400BadRequest
    };

    private static async Task WriteAsync(HttpContext context, int statusCode, string message)
    {
        if (context.Response.HasStarted)
            return;

        // Headers (e.g. CORS) are kept so the browser can read the error body.
        context.Response.StatusCode = statusCode;
        await context.Response.WriteAsJsonAsync(ApiResponse<object>.Fail(message));
    }
}
