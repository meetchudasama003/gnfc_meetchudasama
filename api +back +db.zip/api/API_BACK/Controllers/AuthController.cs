using System.IdentityModel.Tokens.Jwt;
using API_BACK.Application.DTOs.Requests;
using API_BACK.Application.DTOs.Responses;
using API_BACK.Application.Services.Interfaces;
using API_BACK.Contracts;
using API_BACK.Settings;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace API_BACK.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly IAntiforgery _antiforgery;
    private readonly CookieSettings _cookieSettings;

    public AuthController(
        IAuthService authService,
        IAntiforgery antiforgery,
        IOptions<CookieSettings> cookieSettings)
    {
        _authService = authService;
        _antiforgery = antiforgery;
        _cookieSettings = cookieSettings.Value;
    }

    // Issues the antiforgery cookie and returns the matching request token.
    // CORS ensures only the allowed SPA origin can read this response.
    // The token is bound to the current user, so clients fetch a new one after login/logout.
    [HttpGet("csrf")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    [ProducesResponseType(typeof(ApiResponse<CsrfTokenResponse>), StatusCodes.Status200OK)]
    public IActionResult Csrf()
    {
        var tokens = _antiforgery.GetAndStoreTokens(HttpContext);
        return Ok(ApiResponse<CsrfTokenResponse>.Ok(new CsrfTokenResponse { Token = tokens.RequestToken! }));
    }

    [HttpPost("register")]
    [ProducesResponseType(typeof(ApiResponse<UserResponse>), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        var user = await _authService.RegisterAsync(request);
        return StatusCode(StatusCodes.Status201Created,
            ApiResponse<UserResponse>.Ok(user, "Registration successful."));
    }

    [HttpPost("login")]
    [ProducesResponseType(typeof(ApiResponse<AuthResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var result = await _authService.LoginAsync(request);
        if (result is null)
            return Unauthorized(ApiResponse<object>.Fail("Invalid email or password."));

        // The token lives only in an HttpOnly cookie — JavaScript can never read it.
        Response.Cookies.Append(_cookieSettings.Name, result.Token,
            BuildCookieOptions(result.User.ExpiresAt - DateTime.UtcNow));

        return Ok(ApiResponse<AuthResponse>.Ok(result.User, "Login successful."));
    }

    [Authorize]
    [HttpGet("me")]
    [ProducesResponseType(typeof(ApiResponse<AuthResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public IActionResult Me()
    {
        var expClaim = User.FindFirst(JwtRegisteredClaimNames.Exp)?.Value;
        var expiresAt = long.TryParse(expClaim, out var exp)
            ? DateTimeOffset.FromUnixTimeSeconds(exp).UtcDateTime
            : DateTime.UtcNow;

        var me = new AuthResponse
        {
            FullName = User.FindFirst(JwtRegisteredClaimNames.Name)?.Value ?? string.Empty,
            Email = User.FindFirst(JwtRegisteredClaimNames.Email)?.Value ?? string.Empty,
            ExpiresAt = expiresAt
        };
        return Ok(ApiResponse<AuthResponse>.Ok(me));
    }

    [HttpPost("logout")]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
    public IActionResult Logout()
    {
        // Overwrite with an already-expired cookie so the browser deletes it immediately.
        Response.Cookies.Append(_cookieSettings.Name, string.Empty, BuildCookieOptions(TimeSpan.Zero));
        return Ok(ApiResponse<object>.Ok(new { }, "Logged out."));
    }

    private CookieOptions BuildCookieOptions(TimeSpan maxAge) => new()
    {
        HttpOnly = true,
        // SameAsRequest: Secure on HTTPS, relaxed on http://localhost during development.
        Secure = Request.IsHttps,
        SameSite = SameSiteMode.Strict,
        Path = "/",
        MaxAge = maxAge,
        Expires = maxAge == TimeSpan.Zero ? DateTimeOffset.UnixEpoch : null
    };
}
