using API_BACK.Application.DTOs.Responses;
using API_BACK.Application.DTOs.Results;
using API_BACK.Application.Models;
using API_BACK.Application.Services.Interfaces;
using API_BACK.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace API_BACK.Controllers;

[ApiController]
[Authorize]
[Route("api/products")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductsController(IProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<ProductResponse[]>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetAll()
    {
        var products = await _productService.GetAllAsync();
        return Ok(ApiResponse<ProductResponse[]>.Ok(products.ToArray()));
    }

    [HttpPost("upload")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ApiResponse<ProductImportResult>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Upload(IFormFile? file)
    {
        ProductImportResult result;
        if (file is null)
        {
            result = await _productService.ImportAsync(null);
        }
        else
        {
            // Hand the Application layer a framework-neutral stream, not IFormFile.
            await using var stream = file.OpenReadStream();
            result = await _productService.ImportAsync(new FileUpload(stream, file.FileName, file.Length));
        }

        var message = result switch
        {
            { ImportedRecords: 0 } => "No valid records to import.",
            { RejectedRecords: 0 } => "Products imported successfully.",
            _ => $"Import completed with {result.ImportedRecords} imported and {result.RejectedRecords} rejected record(s)."
        };
        return Ok(ApiResponse<ProductImportResult>.Ok(result, message));
    }
}
