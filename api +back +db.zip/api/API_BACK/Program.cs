using API_BACK.Application;
using API_BACK.Application.Settings;
using API_BACK.Extensions;
using API_BACK.Infrastructure;
using API_BACK.Middleware;
using Microsoft.AspNetCore.Http.Features;

var builder = WebApplication.CreateBuilder(args);

// ---------- Layers (Clean Architecture composition root) ----------
builder.Services.AddApplication(builder.Configuration);
builder.Services.AddInfrastructure(builder.Configuration);

// ---------- Web layer ----------
builder.Services.AddApiControllers();
builder.Services.AddJwtCookieAuthentication(builder.Configuration);
builder.Services.AddCorsAndCsrf(builder.Configuration);
builder.Services.AddSwaggerDocumentation();

// ---------- Request size limits ----------
// Allow a little headroom over the file limit for multipart boundaries/headers;
// ProductService enforces the exact file-size limit.
var uploadSettings = builder.Configuration.GetSection(UploadSettings.SectionName).Get<UploadSettings>() ?? new UploadSettings();
var maxRequestBytes = uploadSettings.MaxFileSizeBytes + 64 * 1024;
builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = maxRequestBytes);
builder.Services.Configure<FormOptions>(o => o.MultipartBodyLengthLimit = maxRequestBytes);

var app = builder.Build();

app.UseMiddleware<GlobalExceptionMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseHsts();
    app.UseHttpsRedirection();
}

app.UseCors(ServiceCollectionExtensions.CorsPolicyName);
app.UseAuthentication();
app.UseAuthorization();
// After authorization so unauthenticated calls to protected endpoints get 401 first;
// every state-changing request that gets past it is still CSRF-checked.
app.UseMiddleware<CsrfProtectionMiddleware>();

app.MapControllers();

app.Run();
