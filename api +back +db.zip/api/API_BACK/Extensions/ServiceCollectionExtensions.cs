using API_BACK.Application.Services;
using API_BACK.Application.Settings;
using API_BACK.Contracts;
using API_BACK.Infrastructure.Settings;
using API_BACK.Settings;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace API_BACK.Extensions;

public static class ServiceCollectionExtensions
{
    public const string CorsPolicyName = "Angular";

    public static IServiceCollection AddApiControllers(this IServiceCollection services)
    {
        services.AddControllers()
            .ConfigureApiBehaviorOptions(o =>
            {
                o.InvalidModelStateResponseFactory = context =>
                {
                    // A body over the Kestrel limit surfaces as a form-binding error; report it as a file-size error.
                    if (IsRequestTooLarge(context.HttpContext))
                    {
                        var uploadSettings = context.HttpContext.RequestServices
                            .GetRequiredService<IOptions<UploadSettings>>().Value;
                        return new BadRequestObjectResult(
                            ApiResponse<object>.Fail(ProductService.FileTooLargeMessage(uploadSettings)));
                    }

                    var errors = context.ModelState
                        .Where(kv => kv.Value?.Errors.Count > 0)
                        .ToDictionary(
                            kv => kv.Key,
                            kv => kv.Value!.Errors.Select(e => e.ErrorMessage).ToArray());

                    return new BadRequestObjectResult(
                        ApiResponse<Dictionary<string, string[]>>.Fail("Validation failed.", errors));
                };
            });
        return services;
    }

    private static bool IsRequestTooLarge(HttpContext context)
    {
        var limit = context.Features.Get<IHttpMaxRequestBodySizeFeature>()?.MaxRequestBodySize;
        return limit is not null && context.Request.ContentLength > limit;
    }

    // JWT bearer authentication that reads the token from the HttpOnly cookie.
    public static IServiceCollection AddJwtCookieAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        var jwtSettings = configuration.GetSection(JwtSettings.SectionName).Get<JwtSettings>() ?? new JwtSettings();
        var cookieSettings = configuration.GetSection(CookieSettings.SectionName).Get<CookieSettings>() ?? new CookieSettings();

        if (Encoding.UTF8.GetByteCount(jwtSettings.SecretKey) < 32)
            throw new InvalidOperationException(
                "Jwt:SecretKey must be configured (at least 32 bytes). Set it in appsettings.Development.json, user-secrets or an environment variable.");

        services.Configure<CookieSettings>(configuration.GetSection(CookieSettings.SectionName));

        services
            .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(o =>
            {
                o.MapInboundClaims = false;
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = jwtSettings.Issuer,
                    ValidateAudience = true,
                    ValidAudience = jwtSettings.Audience,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.SecretKey)),
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromSeconds(30),
                    NameClaimType = JwtRegisteredClaimNames.Name
                };
                o.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        context.Token = context.Request.Cookies[cookieSettings.Name];
                        return Task.CompletedTask;
                    },
                    OnChallenge = async context =>
                    {
                        context.HandleResponse();
                        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                        await context.Response.WriteAsJsonAsync(ApiResponse<object>.Fail("Authentication required."));
                    }
                };
            });
        services.AddAuthorization();
        return services;
    }

    // Explicit origin + credentials (required for cookies), plus antiforgery tokens
    // validated by CsrfProtectionMiddleware.
    public static IServiceCollection AddCorsAndCsrf(this IServiceCollection services, IConfiguration configuration)
    {
        var corsSettings = configuration.GetSection(CorsSettings.SectionName).Get<CorsSettings>() ?? new CorsSettings();
        services.Configure<CorsSettings>(configuration.GetSection(CorsSettings.SectionName));

        services.AddCors(o => o.AddPolicy(CorsPolicyName, p => p
            .WithOrigins(corsSettings.AllowedOrigin)
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials()));

        services.AddAntiforgery(o =>
        {
            o.HeaderName = "X-XSRF-TOKEN";
            o.Cookie.Name = "csrf";
            o.Cookie.HttpOnly = true;
            o.Cookie.SameSite = SameSiteMode.Strict;
            o.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
            o.Cookie.Path = "/";
        });
        return services;
    }

    public static IServiceCollection AddSwaggerDocumentation(this IServiceCollection services)
    {
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(c =>
        {
            // Lets Swagger UI send the CSRF header: call GET /api/auth/csrf, then paste data.token via "Authorize".
            c.AddSecurityDefinition("csrf", new OpenApiSecurityScheme
            {
                Type = SecuritySchemeType.ApiKey,
                In = ParameterLocation.Header,
                Name = "X-XSRF-TOKEN",
                Description = "Antiforgery token from GET /api/auth/csrf (data.token)."
            });
            c.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "csrf" } }]
                    = Array.Empty<string>()
            });
        });
        return services;
    }
}
