namespace API_BACK.Settings;

public class CorsSettings
{
    public const string SectionName = "Cors";

    public string AllowedOrigin { get; set; } = "http://localhost:4200";
}
