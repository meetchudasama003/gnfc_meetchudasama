namespace API_BACK.Settings;

public class CookieSettings
{
    public const string SectionName = "Cookie";

    public string Name { get; set; } = "jwt";
}
