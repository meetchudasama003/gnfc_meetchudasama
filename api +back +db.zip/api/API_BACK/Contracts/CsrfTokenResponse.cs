namespace API_BACK.Contracts;

// The antiforgery request token. The client echoes it back in the X-XSRF-TOKEN header.
public class CsrfTokenResponse
{
    public string Token { get; init; } = string.Empty;
}
