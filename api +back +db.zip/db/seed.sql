-- =============================================
-- Optional sample data (products only).
-- Users must be created through POST /api/auth/register so passwords are hashed.
-- =============================================
USE UserProductManagementDB;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Products WHERE ProductCode = N'S001')
    INSERT INTO dbo.Products (ProductCode, ProductName, Category, UnitPrice, Quantity)
    VALUES (N'S001', N'Monitor 24"', N'Electronics', 9500.00, 8);

IF NOT EXISTS (SELECT 1 FROM dbo.Products WHERE ProductCode = N'S002')
    INSERT INTO dbo.Products (ProductCode, ProductName, Category, UnitPrice, Quantity)
    VALUES (N'S002', N'Desk Lamp', N'Furniture', 850.00, 30);
GO
