-- =============================================
-- UserProductManagementDB — schema
-- Run in SSMS against your SQL Server instance.
-- =============================================
IF DB_ID(N'UserProductManagementDB') IS NULL
    CREATE DATABASE UserProductManagementDB;
GO

USE UserProductManagementDB;
GO

-- =============================================
-- Table: Users
-- =============================================
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users (
        UserId       INT            IDENTITY(1,1) PRIMARY KEY,
        FullName     NVARCHAR(200)  NOT NULL,
        Email        NVARCHAR(256)  NOT NULL,
        MobileNumber NVARCHAR(20)   NOT NULL,
        PasswordHash NVARCHAR(MAX)  NOT NULL,         -- hashed with PasswordHasher, never plain text
        CreatedAt    DATETIME2      NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_Users_Email UNIQUE (Email)      -- DB-level duplicate guard
    );

    CREATE INDEX IX_Users_Email ON dbo.Users (Email);
END
GO

-- =============================================
-- Table: Products
-- =============================================
IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products (
        ProductId   INT            IDENTITY(1,1) PRIMARY KEY,
        ProductCode NVARCHAR(50)   NOT NULL,
        ProductName NVARCHAR(200)  NOT NULL,
        Category    NVARCHAR(100)  NOT NULL,
        UnitPrice   DECIMAL(18,2)  NOT NULL CONSTRAINT CK_Products_UnitPrice CHECK (UnitPrice >= 0),
        Quantity    INT            NOT NULL CONSTRAINT CK_Products_Quantity  CHECK (Quantity  >= 0),
        CreatedAt   DATETIME2      NOT NULL CONSTRAINT DF_Products_CreatedAt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT UQ_Products_ProductCode UNIQUE (ProductCode)   -- prevents duplicates
    );

    CREATE INDEX IX_Products_ProductCode ON dbo.Products (ProductCode);
    CREATE INDEX IX_Products_Category    ON dbo.Products (Category);
END
GO
