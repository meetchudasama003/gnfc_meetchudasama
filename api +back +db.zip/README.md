# User Management & Product Import App

A full-stack app for user registration/login and bulk product import from Excel.

**Stack:** .NET 8 Web API · Angular 17 · Dapper · SQL Server · JWT (HttpOnly cookie) · ClosedXML · Bootstrap 5

```
gnfc/
├── api/                               .NET 8 Web API (Clean Architecture)
│   ├── API_BACK.Domain/               Entities — no dependencies
│   ├── API_BACK.Application/          Business logic, interfaces, DTOs
│   ├── API_BACK.Infrastructure/       Dapper/SQL Server, JWT, password hashing, ClosedXML
│   └── API_BACK/                      Web API: controllers, middleware, composition root (API_BACK.sln)
├── front/UserProductManagement.Client Angular 17 SPA
└── db/                                SQL scripts + sample Excel file
```

### Backend architecture

Dependencies point inward only; the compiler enforces this through project references.

```
API_BACK (Web) ──► API_BACK.Application ──► API_BACK.Domain
                         ▲
API_BACK.Infrastructure ─┘
```

| Project | Contains | Depends on |
|---------|----------|-----------|
| **Domain** | `UserEntity`, `ProductEntity` (mirror the DB tables) | nothing |
| **Application** | Services (`AuthService`, `UserService`, `ProductService`) with all business rules and Excel row validation; interfaces it needs (`IUserRepository`, `IProductRepository`, `IPasswordHasher`, `ITokenService`, `ISpreadsheetReader`); request/response DTOs; `ValidationException` / `ConflictException`; `UploadSettings`; `AddApplication()` | Domain only (no SQL, ClosedXML, JWT or ASP.NET) |
| **Infrastructure** | Dapper repositories + transactions, `SqlConnectionFactory`, `JwtTokenService`, `IdentityPasswordHasher`, `ClosedXmlSpreadsheetReader`, `JwtSettings`; `AddInfrastructure()`. Implementations are `internal`. | Application |
| **API_BACK** | Controllers, `GlobalExceptionMiddleware` (maps Application exceptions → 400/409), `CsrfProtectionMiddleware`, cookie/CORS/Swagger setup, `ApiResponse<T>` envelope; `Program.cs` composes the layers | Application, Infrastructure |

Examples of what this buys: `ProductService` validates rows against a plain `SpreadsheetData` model, so ClosedXML could be swapped without touching business rules. Repositories translate SQL Server unique-key errors into `DuplicateKeyException`, so services never see `SqlException`. Controllers pass a `FileUpload` (stream + name + size) instead of `IFormFile`.

---

## 1. Project Overview

- **Register / Login** — passwords are hashed; the JWT is issued as an `HttpOnly`, `SameSite=Strict` cookie.
- **Users** — list all registered users (no password data ever leaves the server).
- **Import Products** — upload an `.xlsx` file; every row is validated, valid rows are saved in a single transaction, invalid rows are reported back with row numbers and reasons.
- **Products** — list, search and refresh imported products.

## 2. Prerequisites

| Tool | Version |
|------|---------|
| .NET SDK | 8.0+ |
| Node.js | 18.13+ (20 LTS recommended) |
| SQL Server | 2019+ (Express/Developer is fine) |
| SSMS or `sqlcmd` | any recent |

## 3. Database Setup

Run `db/database.sql` in SSMS (or from a terminal):

```bash
sqlcmd -S . -E -C -i db/database.sql
```

This creates `UserProductManagementDB` with the `Users` and `Products` tables, unique constraints and indexes. The script is idempotent. `db/seed.sql` optionally adds two sample products. Users must be created through the Register page/API so their passwords are hashed.

## 4. Backend Setup

```bash
cd api/API_BACK
cp appsettings.Development.json.example appsettings.Development.json
# edit appsettings.Development.json:
#   - ConnectionStrings:DefaultConnection → your SQL Server
#   - Jwt:SecretKey → a random string of at least 32 characters
dotnet run --launch-profile http
```

Or open `api/API_BACK/API_BACK.sln` in Visual Studio and run the **API_BACK** project. The API listens on **http://localhost:5000** (Swagger at `/swagger`).

> `appsettings.json` is committed with **empty** secrets. `appsettings.Development.json` holds real local values and is git-ignored. **Never commit secrets.** In production, supply them through environment variables (e.g. `Jwt__SecretKey`, `ConnectionStrings__DefaultConnection`) or a secret store. The API refuses to start if `Jwt:SecretKey` is missing or shorter than 32 bytes.

## 5. Frontend Setup

```bash
cd front/UserProductManagement.Client
npm install
npx ng serve
```

Open **http://localhost:4200**. The API base URL is set in `src/environments/environment.ts`.

---

## 6. Security Implementation

| # | Requirement | How it is implemented | Where |
|---|-------------|------------------------|-------|
| 1 | **Password security** | `IPasswordHasher` (Application) is implemented by `IdentityPasswordHasher` over ASP.NET Core Identity's `PasswordHasher` (PBKDF2, salted). `UserEntity` (which has `PasswordHash`) never leaves the Application layer; `UserResponse` has no hash field. | [AuthService.cs](api/API_BACK.Application/Services/AuthService.cs), [IdentityPasswordHasher.cs](api/API_BACK.Infrastructure/Security/IdentityPasswordHasher.cs), [EntityMappings.cs](api/API_BACK.Application/Mappings/EntityMappings.cs), [UserResponse.cs](api/API_BACK.Application/DTOs/Responses/UserResponse.cs) |
| 2 | **Secrets management** | Empty placeholders in `appsettings.json`; real values in git-ignored `appsettings.Development.json`; consumed via `IOptions<JwtSettings>` / `IOptions<UploadSettings>`; startup check for a missing/weak JWT key. | [appsettings.json](api/API_BACK/appsettings.json), [.gitignore](.gitignore), [JwtSettings.cs](api/API_BACK.Infrastructure/Settings/JwtSettings.cs), [ServiceCollectionExtensions.cs](api/API_BACK/Extensions/ServiceCollectionExtensions.cs) |
| 3 | **Server-side validation** | DataAnnotations on request DTOs (`[Required]`, `[EmailAddress]`, `[RegularExpression]`, `[Compare]`…); `[ApiController]` returns 400 automatically in a uniform `ApiResponse` shape; business rules (unique email) in services; every Excel row validated server-side. | [RegisterRequest.cs](api/API_BACK.Application/DTOs/Requests/RegisterRequest.cs), [LoginRequest.cs](api/API_BACK.Application/DTOs/Requests/LoginRequest.cs), [ProductService.cs](api/API_BACK.Application/Services/ProductService.cs) |
| 4 | **Authentication & authorization** | `JwtTokenService` issues the token; JWT bearer validates signature, issuer, audience and lifetime, reading the token from the cookie in `OnMessageReceived`. `[Authorize]` on `UsersController`, `ProductsController` and `/api/auth/me`. Unauthenticated → `401`. | [JwtTokenService.cs](api/API_BACK.Infrastructure/Security/JwtTokenService.cs), [ServiceCollectionExtensions.cs](api/API_BACK/Extensions/ServiceCollectionExtensions.cs) (`AddJwtCookieAuthentication`), [UsersController.cs](api/API_BACK/Controllers/UsersController.cs), [ProductsController.cs](api/API_BACK/Controllers/ProductsController.cs) |
| 5 | **File upload validation** | Extension must be `.xlsx` **and** the first 4 bytes must be the OOXML/ZIP signature `50 4B 03 04`; the workbook must then open with ClosedXML and contain the required headers. A renamed text file is rejected. | [ProductService.cs](api/API_BACK.Application/Services/ProductService.cs) (`ValidateFile`, `HasZipSignature`, `MapHeaderColumns`), [ClosedXmlSpreadsheetReader.cs](api/API_BACK.Infrastructure/Files/ClosedXmlSpreadsheetReader.cs) |
| 6 | **File size limit** | Kestrel `MaxRequestBodySize` and `FormOptions.MultipartBodyLengthLimit` cap the request; `ProductService` enforces the exact 5 MB limit from `UploadSettings`. A row cap (10,000) prevents oversized sheets. The client pre-check is UX only. | [Program.cs](api/API_BACK/Program.cs), [ProductService.cs](api/API_BACK.Application/Services/ProductService.cs), [product-upload.component.ts](front/UserProductManagement.Client/src/app/features/products/product-upload/product-upload.component.ts) |
| 7 | **SQL injection prevention** | All SQL lives in Infrastructure repositories and uses Dapper named parameters — zero string concatenation. Unique constraints in the DB are the final safety net. | [UserRepository.cs](api/API_BACK.Infrastructure/Persistence/UserRepository.cs), [ProductRepository.cs](api/API_BACK.Infrastructure/Persistence/ProductRepository.cs) |
| 8 | **Exception handling** | `GlobalExceptionMiddleware` logs the full exception server-side and returns only `{"success":false,"message":"An unexpected error occurred."}`. Expected errors are `ValidationException` (→ 400) / `ConflictException` (→ 409) with safe messages. No stack traces reach the client. | [GlobalExceptionMiddleware.cs](api/API_BACK/Middleware/GlobalExceptionMiddleware.cs), [Exceptions/](api/API_BACK.Application/Exceptions/) |
| 9 | **Database consistency** | `ProductRepository.InsertManyAsync` inserts all valid rows inside one `IDbTransaction`; any failure rolls everything back (no partial imports). A concurrent duplicate (unique-constraint violation) becomes `DuplicateKeyException` → `409` with nothing saved. | [ProductRepository.cs](api/API_BACK.Infrastructure/Persistence/ProductRepository.cs), [ProductService.cs](api/API_BACK.Application/Services/ProductService.cs) (`InsertAsync`), [database.sql](db/database.sql) |
| 10 | **JWT storage (XSS/CSRF)** | JWT is set as `HttpOnly; SameSite=Strict; Path=/` cookie (`Secure` on HTTPS). JS never sees it, so XSS cannot steal it. CSRF is blocked by three layers: `SameSite=Strict`, an Origin check, and an antiforgery token (see below). CORS allows only the configured origin with credentials. Angular's interceptor only sets `withCredentials: true`; auth state comes from `GET /api/auth/me`; logout expires the cookie server-side. | [AuthController.cs](api/API_BACK/Controllers/AuthController.cs), [auth.interceptor.ts](front/UserProductManagement.Client/src/app/core/interceptors/auth.interceptor.ts), [auth.service.ts](front/UserProductManagement.Client/src/app/core/services/auth.service.ts), [auth.guard.ts](front/UserProductManagement.Client/src/app/core/guards/auth.guard.ts) |

### CSRF protection (three independent layers)

| Layer | What it does | Where |
|-------|--------------|-------|
| `SameSite=Strict` auth cookie | The browser never attaches the `jwt` cookie to a request started from another site. | [AuthController.cs](api/API_BACK/Controllers/AuthController.cs) |
| Origin check | Every POST/PUT/PATCH/DELETE whose `Origin` (or `Referer`) is not the SPA origin or the API itself is rejected with `403`. This also covers attacks from sibling subdomains, which `SameSite` treats as the same site. | [CsrfProtectionMiddleware.cs](api/API_BACK/Middleware/CsrfProtectionMiddleware.cs) |
| Antiforgery token (double-submit) | `GET /api/auth/csrf` sets an HttpOnly `csrf` cookie and returns a matching request token that only the allowed origin can read (CORS). Every state-changing request must send it in `X-XSRF-TOKEN`; ASP.NET Core `IAntiforgery` validates the pair and that the token belongs to the current user. Missing or invalid → `403`. This blocks cross-site HTML form posts to the upload endpoint, which skip CORS preflight. | [CsrfProtectionMiddleware.cs](api/API_BACK/Middleware/CsrfProtectionMiddleware.cs), [ServiceCollectionExtensions.cs](api/API_BACK/Extensions/ServiceCollectionExtensions.cs) (`AddCorsAndCsrf`) |

On the client, [csrf.service.ts](front/UserProductManagement.Client/src/app/core/services/csrf.service.ts) keeps the token in memory only. [csrf.interceptor.ts](front/UserProductManagement.Client/src/app/core/interceptors/csrf.interceptor.ts) attaches it to every POST, PUT or DELETE sent to the API. Because the token is tied to the user, it is cleared on login/logout and fetched again before the next request; on a `403` the interceptor refreshes it and retries once. Angular's built-in XSRF support is not used because it only works for same-origin relative URLs.

**Swagger:** call `GET /api/auth/csrf`, click **Authorize**, and paste `data.token` into `X-XSRF-TOKEN`. Fetch a new token after logging in.

**How to show it in a browser:** after login, open DevTools → Application → Cookies and see `jwt` marked HttpOnly/SameSite=Strict; run `document.cookie` in the console — the token is not there.

---

## 7. API Reference

All responses use one envelope:

```json
{ "success": true, "message": "Success", "data": { } }
```

| Method | Endpoint | Auth | Success | Errors |
|--------|----------|------|---------|--------|
| GET | `/api/auth/csrf` | — | 200 `{ token }` + `csrf` cookie | — |
| POST | `/api/auth/register` | CSRF | 201 | 400 validation, 403 CSRF, 409 email exists |
| POST | `/api/auth/login` | CSRF | 200 + `Set-Cookie: jwt=…` | 400, 401, 403 |
| GET | `/api/auth/me` | cookie | 200 | 401 |
| POST | `/api/auth/logout` | CSRF | 200 (cookie expired) | 403 |
| GET | `/api/users` | cookie | 200 | 401 |
| GET | `/api/products` | cookie | 200 | 401 |
| POST | `/api/products/upload` | cookie + CSRF | 200 | 400, 401, 403, 409 |

"CSRF" means the request must include the `X-XSRF-TOKEN` header (from `GET /api/auth/csrf`) and the `csrf` cookie.

**Register**

```http
POST /api/auth/register
Content-Type: application/json

{ "fullName": "Test User", "email": "test.user@example.com", "mobileNumber": "9876543210",
  "password": "Passw0rd!", "confirmPassword": "Passw0rd!" }
```

Rules: mobile = 10 digits starting 6–9; password ≥ 8 chars with upper, lower and digit.

**Login** → `200`

```json
{ "success": true, "message": "Login successful.",
  "data": { "fullName": "Test User", "email": "test.user@example.com", "expiresAt": "2026-10-31T08:10:43Z" } }
```

**Validation error** → `400`

```json
{ "success": false, "message": "Validation failed.",
  "data": { "Email": ["The Email field is not a valid e-mail address."] } }
```

**Upload** — `multipart/form-data` with field `file` → `200`

```json
{ "success": true, "message": "Import completed with 2 imported and 1 rejected record(s).",
  "data": { "totalRecords": 3, "importedRecords": 2, "rejectedRecords": 1,
            "errors": [ { "rowNumber": 4, "productCode": "P001",
                          "errors": ["ProductCode already exists in the database."] } ] } }
```

The message is `"Products imported successfully."` when nothing is rejected and `"No valid records to import."` when nothing is valid (still `200`, no transaction opened).

File-level problems return `400` and import nothing: `No file uploaded.`, `Only .xlsx files are accepted.`, `File is not a valid Excel workbook.`, `File size must not exceed 5 MB.`, `Invalid column headers. Expected: ProductCode, ProductName, Category, UnitPrice, Quantity`. A database failure during the insert rolls back the whole transaction and returns a sanitized `500`.

---

## 8. Sample Excel File

`db/sample_products.xlsx`:

| ProductCode | ProductName | Category | UnitPrice | Quantity |
|-------------|-------------|----------|-----------|----------|
| P001 | Laptop | Electronics | 55000.00 | 10 |
| P002 | Keyboard | Accessories | 1200.00 | 25 |
| P003 | Office Chair | Furniture | 4500.00 | 15 |

Sign in → **Import Products** → choose the file → **Upload**. Uploading it a second time rejects all 3 rows as already existing.

Row rules: row 1 must contain exactly `ProductCode | ProductName | Category | UnitPrice | Quantity` in columns 1–5 (case-insensitive); data starts at row 2. Every error in a row is reported, not just the first. `ProductCode` is required, at most 50 characters, and unique (case-insensitive) both within the file and in the database. `ProductName` is required, at most 200 characters. `Category` is required, at most 100 characters. `UnitPrice` must be a number ≥ 0 with at most 2 decimals. `Quantity` must be a whole number ≥ 0. Blank rows are skipped.
