export const environment = {
  production: true,
  // Set to the deployed API origin (must be same-site with the SPA for the SameSite=Strict cookie).
  apiBaseUrl: ''
};
