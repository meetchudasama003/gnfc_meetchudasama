import { Component, ElementRef, ViewChild, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { ProductImportResult } from '../../../core/models/product.model';
import { ProductService } from '../../../core/services/product.service';
import { getErrorMessage } from '../../../core/utils/http-error';

const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024;
const ALLOWED_EXTENSION = '.xlsx';

@Component({
  selector: 'app-product-upload',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './product-upload.component.html'
})
export class ProductUploadComponent {
  private readonly productService = inject(ProductService);

  @ViewChild('fileInput') private fileInput?: ElementRef<HTMLInputElement>;

  selectedFile: File | null = null;
  fileError = '';
  uploading = false;
  errorMessage = '';
  result: ProductImportResult | null = null;
  resultMessage = '';

  readonly maxSizeMb = MAX_FILE_SIZE_BYTES / (1024 * 1024);

  // Client-side checks are for UX only — the server is the authoritative gate.
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;

    this.selectedFile = null;
    this.fileError = '';
    this.errorMessage = '';
    this.result = null;

    if (!file) {
      return;
    }
    if (!file.name.toLowerCase().endsWith(ALLOWED_EXTENSION)) {
      this.fileError = 'Please select a valid .xlsx file.';
      return;
    }
    if (file.size === 0) {
      this.fileError = 'The selected file is empty.';
      return;
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      this.fileError = `File size must not exceed ${this.maxSizeMb} MB.`;
      return;
    }
    this.selectedFile = file;
  }

  upload(): void {
    if (!this.selectedFile || this.uploading) {
      return;
    }

    this.uploading = true;
    this.errorMessage = '';
    this.result = null;

    const formData = new FormData();
    formData.append('file', this.selectedFile, this.selectedFile.name);

    this.productService
      .uploadExcel(formData)
      .pipe(finalize(() => (this.uploading = false)))
      .subscribe({
        next: res => {
          this.result = res.data;
          this.resultMessage = res.message;
        },
        error: err => (this.errorMessage = getErrorMessage(err, 'An unexpected error occurred.'))
      });
  }

  /** "Upload Another File": clears the file input, summary and errors. */
  reset(): void {
    this.selectedFile = null;
    this.fileError = '';
    this.errorMessage = '';
    this.result = null;
    this.resultMessage = '';
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  formatSize(bytes: number): string {
    return bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(1)} KB` : `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  }
}
