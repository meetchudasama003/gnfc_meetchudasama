import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { ProductResponse } from '../../../core/models/product.model';
import { ProductService } from '../../../core/services/product.service';
import { getErrorMessage } from '../../../core/utils/http-error';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CurrencyPipe, DatePipe, FormsModule, RouterLink],
  templateUrl: './product-list.component.html'
})
export class ProductListComponent implements OnInit {
  private readonly productService = inject(ProductService);

  products: ProductResponse[] = [];
  search = '';
  loading = false;
  errorMessage = '';

  get filteredProducts(): ProductResponse[] {
    const term = this.search.trim().toLowerCase();
    if (!term) {
      return this.products;
    }
    return this.products.filter(p =>
      [p.productCode, p.productName, p.category].some(v => v.toLowerCase().includes(term))
    );
  }

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.errorMessage = '';
    this.productService
      .getAll()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
        next: products => (this.products = products),
        error: err => (this.errorMessage = getErrorMessage(err, 'Failed to load products.'))
      });
  }
}
