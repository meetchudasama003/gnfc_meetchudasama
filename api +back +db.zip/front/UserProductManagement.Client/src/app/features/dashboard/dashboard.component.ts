import { AsyncPipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [AsyncPipe, RouterLink],
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent {
  readonly currentUser$ = inject(AuthService).currentUser$;

  readonly tiles = [
    { title: 'Users', text: 'View all registered users.', link: '/users', action: 'View users' },
    { title: 'Import Products', text: 'Upload an .xlsx file to bulk-import products.', link: '/products/upload', action: 'Upload file' },
    { title: 'Products', text: 'Browse all imported products.', link: '/products/list', action: 'View products' }
  ];
}
