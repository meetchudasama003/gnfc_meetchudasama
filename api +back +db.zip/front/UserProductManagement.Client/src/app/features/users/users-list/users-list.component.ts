import { DatePipe } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { finalize } from 'rxjs';
import { UserResponse } from '../../../core/models/user.model';
import { UserService } from '../../../core/services/user.service';
import { getErrorMessage } from '../../../core/utils/http-error';

@Component({
  selector: 'app-users-list',
  standalone: true,
  imports: [DatePipe],
  templateUrl: './users-list.component.html'
})
export class UsersListComponent implements OnInit {
  private readonly userService = inject(UserService);

  users: UserResponse[] = [];
  loading = false;
  errorMessage = '';

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.errorMessage = '';
    this.userService
      .getAll()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
        next: users => (this.users = users),
        error: err => (this.errorMessage = getErrorMessage(err, 'Failed to load users.'))
      });
  }
}
