import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { getErrorMessage, getValidationErrors } from '../../../core/utils/http-error';
import {
  mobileNumberValidator,
  passwordMatchValidator,
  passwordStrengthValidator
} from '../../../shared/validators/custom-validators';

type RegisterField = 'fullName' | 'email' | 'mobileNumber' | 'password' | 'confirmPassword';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  private readonly fb = inject(FormBuilder);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  submitting = false;
  errorMessage = '';
  serverErrors: string[] = [];

  readonly form = this.fb.nonNullable.group(
    {
      fullName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(200)]],
      email: ['', [Validators.required, Validators.email, Validators.maxLength(256)]],
      mobileNumber: ['', [Validators.required, mobileNumberValidator()]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(100), passwordStrengthValidator()]],
      confirmPassword: ['', [Validators.required]]
    },
    { validators: passwordMatchValidator }
  );

  isInvalid(name: RegisterField): boolean {
    const control = this.form.controls[name];
    return control.invalid && (control.touched || control.dirty);
  }

  hasError(name: RegisterField, error: string): boolean {
    return this.form.controls[name].hasError(error);
  }

  submit(): void {
    if (this.form.invalid || this.submitting) {
      this.form.markAllAsTouched();
      return;
    }

    this.submitting = true;
    this.errorMessage = '';
    this.serverErrors = [];

    const value = this.form.getRawValue();
    this.authService
      .register({ ...value, fullName: value.fullName.trim(), email: value.email.trim() })
      .pipe(finalize(() => (this.submitting = false)))
      .subscribe({
        next: () => this.router.navigate(['/login'], { queryParams: { registered: 1 } }),
        error: err => {
          this.errorMessage = getErrorMessage(err, 'Registration failed.');
          this.serverErrors = getValidationErrors(err);
        }
      });
  }
}
