import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/** Group-level validator: sets `passwordMismatch` on the confirmPassword control. */
export function passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
  const password = control.get('password');
  const confirm = control.get('confirmPassword');
  if (!password || !confirm) {
    return null;
  }

  const mismatch = !!confirm.value && password.value !== confirm.value;
  const { passwordMismatch, ...otherErrors } = confirm.errors ?? {};

  if (mismatch) {
    confirm.setErrors({ ...otherErrors, passwordMismatch: true });
  } else if (passwordMismatch) {
    confirm.setErrors(Object.keys(otherErrors).length ? otherErrors : null);
  }
  return mismatch ? { passwordMismatch: true } : null;
}

/** Indian mobile number: 10 digits starting with 6-9 (matches the API rule). */
export function mobileNumberValidator(): ValidatorFn {
  const pattern = /^[6-9]\d{9}$/;
  return (control: AbstractControl): ValidationErrors | null => {
    const value = (control.value ?? '').toString().trim();
    if (!value) {
      return null; // leave "required" to Validators.required
    }
    return pattern.test(value) ? null : { mobileNumber: true };
  };
}

/** At least one uppercase, one lowercase and one digit (matches the API rule). */
export function passwordStrengthValidator(): ValidatorFn {
  const pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value ?? '';
    if (!value) {
      return null;
    }
    return pattern.test(value) ? null : { passwordStrength: true };
  };
}
