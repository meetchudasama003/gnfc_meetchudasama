// No token field — the JWT lives in an HttpOnly cookie that JavaScript cannot read.
export interface AuthResponse {
  fullName: string;
  email: string;
  expiresAt: string;
}

/** Antiforgery request token, echoed back in the X-XSRF-TOKEN header. */
export interface CsrfTokenResponse {
  token: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  fullName: string;
  email: string;
  mobileNumber: string;
  password: string;
  confirmPassword: string;
}
