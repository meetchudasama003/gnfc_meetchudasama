export interface ProductResponse {
  productId: number;
  productCode: string;
  productName: string;
  category: string;
  unitPrice: number;
  quantity: number;
  createdAt: string;
}

export interface RowValidationError {
  rowNumber: number;
  productCode: string;
  errors: string[];
}

export interface ProductImportResult {
  totalRecords: number;
  importedRecords: number;
  rejectedRecords: number;
  errors: RowValidationError[];
}
