export interface UserResponse {
  userId: number;
  fullName: string;
  email: string;
  mobileNumber: string;
  createdAt: string;
}
