import { HttpErrorResponse, HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, switchMap, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { CsrfService } from '../services/csrf.service';

const SAFE_METHODS = ['GET', 'HEAD', 'OPTIONS'];
const CSRF_HEADER = 'X-XSRF-TOKEN';

/**
 * Adds the antiforgery token to every state-changing API request.
 * Angular's built-in XSRF support only covers relative URLs, and this API is on
 * another origin, so the token is fetched from GET /api/auth/csrf instead of a cookie.
 * On 403 (stale token, e.g. after the session changed) it refreshes the token and retries once.
 */
export const csrfInterceptor: HttpInterceptorFn = (req, next) => {
  if (SAFE_METHODS.includes(req.method) || !isApiRequest(req)) {
    return next(req);
  }

  const csrf = inject(CsrfService);
  const withToken = (token: string) => req.clone({ setHeaders: { [CSRF_HEADER]: token } });

  return csrf.getToken().pipe(
    switchMap(token => next(withToken(token))),
    catchError((err: unknown) => {
      if (err instanceof HttpErrorResponse && err.status === 403) {
        return csrf.refreshToken().pipe(switchMap(token => next(withToken(token))));
      }
      return throwError(() => err);
    })
  );
};

// Never send the token to third-party hosts.
function isApiRequest(req: HttpRequest<unknown>): boolean {
  return environment.apiBaseUrl ? req.url.startsWith(environment.apiBaseUrl) : req.url.startsWith('/');
}
