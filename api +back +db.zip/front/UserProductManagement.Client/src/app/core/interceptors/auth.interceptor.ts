import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';

/**
 * Cookie mode: only sets withCredentials so the browser attaches the HttpOnly JWT cookie.
 * No Authorization header — Angular never sees the token.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const authReq = req.clone({ withCredentials: true });

  return next(authReq).pipe(
    catchError((err: unknown) => {
      // /api/auth/* endpoints report 401 as a normal outcome (bad login, no session yet).
      const isAuthEndpoint = req.url.includes('/api/auth/');
      if (err instanceof HttpErrorResponse && err.status === 401 && !isAuthEndpoint) {
        authService.handleUnauthorized();
      }
      return throwError(() => err);
    })
  );
};
