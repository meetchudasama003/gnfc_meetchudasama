import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, finalize, map, of, shareReplay, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { CsrfTokenResponse } from '../models/auth.model';

/**
 * Holds the antiforgery request token in memory only (never in storage).
 * The token is bound to the signed-in user, so it is cleared on login/logout
 * and fetched again lazily before the next state-changing request.
 */
@Injectable({ providedIn: 'root' })
export class CsrfService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiBaseUrl}/api/auth/csrf`;

  private token: string | null = null;
  private pending$: Observable<string> | null = null;

  getToken(): Observable<string> {
    return this.token ? of(this.token) : this.refreshToken();
  }

  refreshToken(): Observable<string> {
    if (!this.pending$) {
      this.pending$ = this.http.get<ApiResponse<CsrfTokenResponse>>(this.url).pipe(
        map(res => res.data?.token ?? ''),
        tap(token => (this.token = token)),
        finalize(() => (this.pending$ = null)),
        shareReplay(1)
      );
    }
    return this.pending$;
  }

  clear(): void {
    this.token = null;
  }
}
