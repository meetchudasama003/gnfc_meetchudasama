import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { ProductImportResult, ProductResponse } from '../models/product.model';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = `${environment.apiBaseUrl}/api/products`;

  getAll(): Observable<ProductResponse[]> {
    return this.http.get<ApiResponse<ProductResponse[]>>(this.baseUrl).pipe(map(res => res.data ?? []));
  }

  // Never set Content-Type manually: the browser adds multipart/form-data with the boundary.
  // withCredentials and the CSRF header are added by the interceptors.
  uploadExcel(formData: FormData): Observable<ApiResponse<ProductImportResult>> {
    return this.http.post<ApiResponse<ProductImportResult>>(`${this.baseUrl}/upload`, formData);
  }
}
