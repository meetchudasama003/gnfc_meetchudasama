import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, catchError, finalize, map, of, shareReplay, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { AuthResponse, LoginRequest, RegisterRequest } from '../models/auth.model';
import { UserResponse } from '../models/user.model';
import { CsrfService } from './csrf.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly csrf = inject(CsrfService);
  private readonly baseUrl = `${environment.apiBaseUrl}/api/auth`;

  private readonly currentUserSubject = new BehaviorSubject<AuthResponse | null>(null);
  private readonly isAuthenticatedSubject = new BehaviorSubject<boolean>(false);

  readonly currentUser$ = this.currentUserSubject.asObservable();
  readonly isAuthenticated$ = this.isAuthenticatedSubject.asObservable();

  private sessionChecked = false;
  private sessionCheck$: Observable<boolean> | null = null;

  /**
   * Resolves whether the browser holds a valid session cookie by asking the API.
   * The result is cached after the first call; login/logout update it directly.
   */
  ensureSession(): Observable<boolean> {
    if (this.sessionChecked) {
      return of(this.isAuthenticatedSubject.value);
    }
    if (!this.sessionCheck$) {
      this.sessionCheck$ = this.http.get<ApiResponse<AuthResponse>>(`${this.baseUrl}/me`).pipe(
        map(res => res.data),
        catchError(() => of(null)),
        tap(user => {
          this.setUser(user);
          this.sessionChecked = true;
        }),
        map(user => user !== null),
        finalize(() => (this.sessionCheck$ = null)),
        shareReplay(1)
      );
    }
    return this.sessionCheck$;
  }

  login(request: LoginRequest): Observable<AuthResponse> {
    return this.http.post<ApiResponse<AuthResponse>>(`${this.baseUrl}/login`, request).pipe(
      map(res => res.data as AuthResponse),
      tap(user => {
        this.setUser(user);
        this.sessionChecked = true;
        // The CSRF token is bound to the user; the anonymous one is no longer valid.
        this.csrf.clear();
      })
    );
  }

  register(request: RegisterRequest): Observable<ApiResponse<UserResponse>> {
    return this.http.post<ApiResponse<UserResponse>>(`${this.baseUrl}/register`, request);
  }

  /** Asks the API to expire the HttpOnly cookie, then clears local state. */
  logout(): void {
    this.http
      .post<ApiResponse<object>>(`${this.baseUrl}/logout`, {})
      .pipe(catchError(() => of(null)))
      .subscribe(() => this.clearSessionAndRedirect());
  }

  /** Called by the interceptor when a protected request returns 401 (e.g. expired cookie). */
  handleUnauthorized(): void {
    if (this.isAuthenticatedSubject.value) {
      this.logout();
    } else {
      this.clearSessionAndRedirect();
    }
  }

  private clearSessionAndRedirect(): void {
    this.setUser(null);
    this.sessionChecked = true;
    this.csrf.clear();
    this.router.navigate(['/login']);
  }

  private setUser(user: AuthResponse | null): void {
    this.currentUserSubject.next(user);
    this.isAuthenticatedSubject.next(user !== null);
  }
}
