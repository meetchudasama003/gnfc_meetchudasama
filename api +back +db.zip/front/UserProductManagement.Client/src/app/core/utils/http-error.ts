import { HttpErrorResponse } from '@angular/common/http';
import { ApiResponse } from '../models/api-response.model';

/** Extracts a user-friendly message from an API error (ApiResponse envelope). */
export function getErrorMessage(err: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (err instanceof HttpErrorResponse) {
    if (err.status === 0) {
      return 'Unable to reach the server. Please check your connection.';
    }
    const body = err.error as Partial<ApiResponse<unknown>> | null;
    if (body && typeof body.message === 'string' && body.message) {
      return body.message;
    }
  }
  return fallback;
}

/** Flattens server-side validation errors ({ field: [messages] }) into a list. */
export function getValidationErrors(err: unknown): string[] {
  if (err instanceof HttpErrorResponse && err.status === 400) {
    const data = (err.error as Partial<ApiResponse<Record<string, string[]>>> | null)?.data;
    if (data && typeof data === 'object') {
      return Object.values(data).flat();
    }
  }
  return [];
}
