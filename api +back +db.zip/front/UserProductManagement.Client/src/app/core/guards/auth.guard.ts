import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';
import { AuthService } from '../services/auth.service';

/** Allows navigation only when GET /api/auth/me confirms a valid session cookie. */
export const authGuard: CanActivateFn = (_route, state) => {
  const router = inject(Router);
  return inject(AuthService)
    .ensureSession()
    .pipe(map(ok => ok || router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } })));
};

/** Keeps signed-in users away from the login/register pages. */
export const guestGuard: CanActivateFn = () => {
  const router = inject(Router);
  return inject(AuthService)
    .ensureSession()
    .pipe(map(ok => (ok ? router.createUrlTree(['/dashboard']) : true)));
};
